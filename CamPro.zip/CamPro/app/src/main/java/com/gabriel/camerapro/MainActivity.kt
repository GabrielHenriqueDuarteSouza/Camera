package com.gabriel.camerapro

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * CamPro - câmera própria usando a API Camera2.
 *  - escolha de câmera (inclusive lentes físicas, quando o sistema liberar)
 *  - escolha de resolução do JPEG
 *  - salvar JPEG ou JPEG + RAW (DNG), quando a câmera expõe RAW
 *  - exposição manual (ISO + obturador), foco manual, balanço de branco, zoom, EV
 *  - "processamento mínimo" (pede redução de ruído mínima e nitidez desligada)
 *  - botão Info: relatório do que o aparelho realmente libera para apps de terceiros
 */
class MainActivity : Activity() {

    private class CamEntry(val logicalId: String, val physicalId: String?, val label: String) {
        val charsId: String
            get() = physicalId ?: logicalId
    }

    private class CaptureJob(
        val expectRaw: Boolean,
        val jpegOrientation: Int,
        val chars: CameraCharacteristics,
        val physicalId: String?
    ) {
        @Volatile var jpeg: Image? = null
        @Volatile var raw: Image? = null
        @Volatile var result: TotalCaptureResult? = null
    }

    companion object {
        private const val REQ_CAMERA = 10
        private const val MAX_EXPOSURE_NS = 2_000_000_000L
        private const val EXIF_NORMAL = 1
        private const val EXIF_ROTATE_90 = 6
        private const val EXIF_ROTATE_180 = 3
        private const val EXIF_ROTATE_270 = 8
    }

    // ---------- views ----------
    private lateinit var textureView: AutoFitTextureView
    private lateinit var statusText: TextView
    private lateinit var btnInfo: Button
    private lateinit var btnCamera: Button
    private lateinit var btnRes: Button
    private lateinit var btnRaw: Button
    private lateinit var btnExp: Button
    private lateinit var btnFocus: Button
    private lateinit var btnWb: Button
    private lateinit var btnProc: Button
    private lateinit var btnShutter: Button
    private lateinit var rowZoom: View
    private lateinit var rowEv: View
    private lateinit var rowIso: View
    private lateinit var rowShutter: View
    private lateinit var rowFocus: View
    private lateinit var labelZoom: TextView
    private lateinit var labelEv: TextView
    private lateinit var labelIso: TextView
    private lateinit var labelShutter: TextView
    private lateinit var labelFocus: TextView
    private lateinit var seekZoom: SeekBar
    private lateinit var seekEv: SeekBar
    private lateinit var seekIso: SeekBar
    private lateinit var seekShutter: SeekBar
    private lateinit var seekFocus: SeekBar

    // ---------- estado da câmera ----------
    private lateinit var cameraManager: CameraManager
    private var entries: List<CamEntry> = emptyList()
    private var entryIndex = 0
    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var logicalChars: CameraCharacteristics? = null
    private var previewSurface: Surface? = null
    private var previewSize = Size(1280, 960)
    private var jpegSizes: List<Size> = emptyList()
    private var jpegSizeIndex = 0
    private var rawSize: Size? = null
    private var rawSupported = false
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null

    @Volatile private var job: CaptureJob? = null
    @Volatile private var opening = false
    private var resumed = false

    private var bgThread: HandlerThread? = null
    @Volatile private var bgHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val sessionExecutor = Executor { r -> bgHandler?.post(r) }
    private var orientationListener: OrientationEventListener? = null
    @Volatile private var deviceOrientation = 0

    // ---------- capacidades da câmera atual ----------
    private var manualSupported = false
    private var isoMin = 100
    private var isoMax = 100
    private var expMin = 1_000_000L
    private var expMax = 1_000_000L
    private var evMin = 0
    private var evMax = 0
    private var evStep = 0.33f
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var minFocus = 0f
    private var afContinuous = false
    private var awbModes: List<Int> = listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO)
    private var nrMinimal = false
    private var edgeOff = false

    // ---------- ajustes do usuário ----------
    private var rawMode = false
    private var manualExposure = false
    private var manualFocus = false
    private var minimalProcessing = false
    private var zoomRatio = 1f
    private var evIndex = 0
    private var isoValue = 100
    private var exposureNs = 10_000_000L
    private var focusDiopter = 0f
    private var awbIndex = 0

    // últimos valores reais reportados pelo preview (para iniciar o modo manual de onde o auto parou)
    @Volatile private var lastIso = 100
    @Volatile private var lastExp = 10_000_000L
    @Volatile private var lastFocus = 0f

    // =====================================================================
    // Ciclo de vida
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        bindViews()
        setupListeners()
        orientationListener = object : OrientationEventListener(this@MainActivity) {
            override fun onOrientationChanged(orientation: Int) {
                deviceOrientation = orientation
            }
        }
        try {
            buildEntries()
        } catch (e: Exception) {
            toast("Erro ao listar câmeras: ${e.message}")
        }
        if (!hasCameraPermission()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
        }
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        startBackgroundThread()
        orientationListener?.let { if (it.canDetectOrientation()) it.enable() }
        if (textureView.isAvailable) openCamera()
    }

    override fun onPause() {
        resumed = false
        closeCamera()
        orientationListener?.disable()
        stopBackgroundThread()
        super.onPause()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAMERA) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (textureView.isAvailable) openCamera()
            } else {
                toast("Sem permissão de câmera o app não funciona.")
            }
        }
    }

    private fun hasCameraPermission(): Boolean =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startBackgroundThread() {
        val t = HandlerThread("CamPro-bg")
        t.start()
        bgThread = t
        bgHandler = Handler(t.looper)
    }

    private fun stopBackgroundThread() {
        bgThread?.quitSafely()
        try {
            bgThread?.join(1000)
        } catch (e: InterruptedException) {
            // ignora
        }
        bgThread = null
        bgHandler = null
    }

    // =====================================================================
    // Interface
    // =====================================================================

    private fun bindViews() {
        textureView = findViewById(R.id.textureView)
        statusText = findViewById(R.id.statusText)
        btnInfo = findViewById(R.id.btnInfo)
        btnCamera = findViewById(R.id.btnCamera)
        btnRes = findViewById(R.id.btnRes)
        btnRaw = findViewById(R.id.btnRaw)
        btnExp = findViewById(R.id.btnExp)
        btnFocus = findViewById(R.id.btnFocus)
        btnWb = findViewById(R.id.btnWb)
        btnProc = findViewById(R.id.btnProc)
        btnShutter = findViewById(R.id.btnShutter)
        rowZoom = findViewById(R.id.rowZoom)
        rowEv = findViewById(R.id.rowEv)
        rowIso = findViewById(R.id.rowIso)
        rowShutter = findViewById(R.id.rowShutter)
        rowFocus = findViewById(R.id.rowFocus)
        labelZoom = findViewById(R.id.labelZoom)
        labelEv = findViewById(R.id.labelEv)
        labelIso = findViewById(R.id.labelIso)
        labelShutter = findViewById(R.id.labelShutter)
        labelFocus = findViewById(R.id.labelFocus)
        seekZoom = findViewById(R.id.seekZoom)
        seekEv = findViewById(R.id.seekEv)
        seekIso = findViewById(R.id.seekIso)
        seekShutter = findViewById(R.id.seekShutter)
        seekFocus = findViewById(R.id.seekFocus)
    }

    private fun userSeek(block: (Int) -> Unit): SeekBar.OnSeekBarChangeListener {
        return object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) block(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                openCamera()
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        // pinça na imagem = zoom
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    setZoom(zoomRatio * detector.scaleFactor)
                    return true
                }
            })
        textureView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            true
        }

        btnCamera.setOnClickListener {
            if (entries.size < 2) {
                toast("Só há uma câmera disponível para apps (veja Info).")
                return@setOnClickListener
            }
            entryIndex = (entryIndex + 1) % entries.size
            jpegSizeIndex = 0
            zoomRatio = 1f
            restartCamera()
        }
        btnRes.setOnClickListener {
            if (jpegSizes.size < 2) return@setOnClickListener
            jpegSizeIndex = (jpegSizeIndex + 1) % jpegSizes.size
            restartCamera()
        }
        btnRaw.setOnClickListener {
            if (!rawSupported) {
                toast("Esta câmera não oferece RAW para apps (veja Info).")
                return@setOnClickListener
            }
            rawMode = !rawMode
            restartCamera()
        }
        btnExp.setOnClickListener { toggleManualExposure() }
        btnFocus.setOnClickListener { toggleManualFocus() }
        btnWb.setOnClickListener {
            awbIndex = (awbIndex + 1) % awbModes.size
            refreshUi()
            startPreview()
        }
        btnProc.setOnClickListener {
            if (!nrMinimal && !edgeOff) {
                toast("Esta câmera não aceita reduzir o processamento por aqui.")
                return@setOnClickListener
            }
            minimalProcessing = !minimalProcessing
            refreshUi()
            startPreview()
        }
        btnInfo.setOnClickListener { showInfo() }
        btnShutter.setOnClickListener { takePicture() }

        seekZoom.setOnSeekBarChangeListener(userSeek { p ->
            zoomRatio = logMap(p, zoomMin.toDouble(), zoomMax.toDouble()).toFloat()
            updateLabels()
            startPreview()
        })
        seekEv.setOnSeekBarChangeListener(userSeek { p ->
            evIndex = evMin + p
            updateLabels()
            startPreview()
        })
        seekIso.setOnSeekBarChangeListener(userSeek { p ->
            isoValue = logMap(p, isoMin.toDouble(), isoMax.toDouble()).roundToInt().coerceIn(isoMin, isoMax)
            updateLabels()
            startPreview()
        })
        seekShutter.setOnSeekBarChangeListener(userSeek { p ->
            exposureNs = logMap(p, expMin.toDouble(), expMax.toDouble()).toLong().coerceIn(expMin, expMax)
            updateLabels()
            startPreview()
        })
        seekFocus.setOnSeekBarChangeListener(userSeek { p ->
            focusDiopter = p / 1000f * minFocus
            updateLabels()
            startPreview()
        })
    }

    private fun setZoom(r: Float) {
        if (zoomMax <= zoomMin) return
        zoomRatio = r.coerceIn(zoomMin, zoomMax)
        seekZoom.progress = logUnmap(zoomRatio.toDouble(), zoomMin.toDouble(), zoomMax.toDouble())
        updateLabels()
        startPreview()
    }

    private fun toggleManualExposure() {
        if (!manualSupported) {
            toast("Esta câmera não libera exposição manual para apps (veja Info).")
            return
        }
        manualExposure = !manualExposure
        if (manualExposure) {
            isoValue = lastIso.coerceIn(isoMin, isoMax)
            exposureNs = lastExp.coerceIn(expMin, expMax)
        }
        initSeeks()
        refreshUi()
        startPreview()
    }

    private fun toggleManualFocus() {
        if (minFocus <= 0f) {
            toast("Esta câmera tem foco fixo (ou não libera foco manual).")
            return
        }
        manualFocus = !manualFocus
        if (manualFocus) {
            focusDiopter = lastFocus.coerceIn(0f, minFocus)
        }
        initSeeks()
        refreshUi()
        startPreview()
    }

    private fun initSeeks() {
        seekZoom.max = 1000
        seekZoom.progress = logUnmap(zoomRatio.toDouble(), zoomMin.toDouble(), zoomMax.toDouble())
        evIndex = evIndex.coerceIn(evMin, evMax)
        seekEv.max = evMax - evMin
        seekEv.progress = evIndex - evMin
        seekIso.max = 1000
        seekIso.progress = logUnmap(isoValue.toDouble(), isoMin.toDouble(), isoMax.toDouble())
        seekShutter.max = 1000
        seekShutter.progress = logUnmap(exposureNs.toDouble(), expMin.toDouble(), expMax.toDouble())
        seekFocus.max = 1000
        seekFocus.progress =
            if (minFocus > 0f) (focusDiopter / minFocus * 1000f).roundToInt().coerceIn(0, 1000) else 0
    }

    private fun updateLabels() {
        labelZoom.text = String.format(Locale.US, "Zoom: %.1fx  (pinça na imagem também funciona)", zoomRatio)
        labelEv.text = String.format(Locale.US, "Exposição (EV): %+.1f", evIndex * evStep)
        labelIso.text = "ISO: $isoValue"
        val s = exposureNs / 1e9
        labelShutter.text = if (s < 0.5) {
            "Obturador: 1/${(1.0 / s).roundToInt()} s"
        } else {
            String.format(Locale.US, "Obturador: %.1f s", s)
        }
        labelFocus.text = if (focusDiopter <= 0.01f) {
            "Foco: infinito"
        } else {
            String.format(Locale.US, "Foco: %.0f cm", 100f / focusDiopter)
        }
    }

    private fun refreshUi() {
        val entry = entries.getOrNull(entryIndex)
        val size = jpegSizes.getOrNull(jpegSizeIndex)
        btnRes.text = if (size != null) {
            String.format(Locale.US, "Res: %.1f MP", size.width.toLong() * size.height / 1e6)
        } else {
            "Res: ?"
        }
        btnRaw.text = if (!rawSupported) {
            "RAW: indisponível"
        } else if (rawMode) {
            "Salvar: JPEG+RAW"
        } else {
            "Salvar: JPEG"
        }
        btnExp.text = if (manualExposure) "Exp: Manual" else "Exp: Auto"
        btnFocus.text = if (manualFocus) "Foco: Manual" else "Foco: Auto"
        val awb = awbModes.getOrNull(awbIndex) ?: CameraMetadata.CONTROL_AWB_MODE_AUTO
        btnWb.text = "WB: " + awbName(awb)
        btnProc.text = if (minimalProcessing) "Proc.: Mínimo" else "Proc.: Padrão"

        val sizeTxt = if (size != null) "${size.width}x${size.height}" else "?"
        statusText.text = (entry?.label ?: "Sem câmera") + "  •  " + sizeTxt + "  •  " +
            (if (rawMode) "JPEG+RAW" else "JPEG")

        rowZoom.visibility = if (zoomMax > zoomMin) View.VISIBLE else View.GONE
        rowEv.visibility = if (!manualExposure && evMax > evMin) View.VISIBLE else View.GONE
        rowIso.visibility = if (manualExposure) View.VISIBLE else View.GONE
        rowShutter.visibility = if (manualExposure) View.VISIBLE else View.GONE
        rowFocus.visibility = if (manualFocus) View.VISIBLE else View.GONE

        val front = logicalChars?.get(CameraCharacteristics.LENS_FACING) == CameraMetadata.LENS_FACING_FRONT
        textureView.scaleX = if (front) -1f else 1f
        updateLabels()
    }

    private fun awbName(mode: Int): String = when (mode) {
        CameraMetadata.CONTROL_AWB_MODE_AUTO -> "Auto"
        CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT -> "Incandescente"
        CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT -> "Fluorescente"
        CameraMetadata.CONTROL_AWB_MODE_WARM_FLUORESCENT -> "Fluor. quente"
        CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT -> "Luz do dia"
        CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT -> "Nublado"
        CameraMetadata.CONTROL_AWB_MODE_TWILIGHT -> "Crepúsculo"
        CameraMetadata.CONTROL_AWB_MODE_SHADE -> "Sombra"
        else -> "modo $mode"
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    // =====================================================================
    // Descoberta de câmeras
    // =====================================================================

    private fun focalDesc(c: CameraCharacteristics): String {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return ""
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        return if (sz != null) {
            val diag = sqrt((sz.width * sz.width + sz.height * sz.height).toDouble())
            val eq = f * 43.27 / diag
            String.format(Locale.US, "%.1fmm (~%.0fmm eq.)", f, eq)
        } else {
            String.format(Locale.US, "%.1fmm", f)
        }
    }

    private fun facingName(f: Int?): String = when (f) {
        CameraMetadata.LENS_FACING_FRONT -> "Frontal"
        CameraMetadata.LENS_FACING_BACK -> "Traseira"
        CameraMetadata.LENS_FACING_EXTERNAL -> "Externa"
        else -> "?"
    }

    private fun buildEntries() {
        val list = ArrayList<CamEntry>()
        var defaultIndex = -1
        for (id in cameraManager.cameraIdList) {
            val c = cameraManager.getCameraCharacteristics(id)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
            if (!caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            val name = facingName(facing)
            if (defaultIndex < 0 && facing == CameraMetadata.LENS_FACING_BACK) defaultIndex = list.size
            list.add(CamEntry(id, null, "[$id] $name ${focalDesc(c)}"))
            val phys = c.physicalCameraIds
            if (phys.size > 1) {
                for (p in phys.sorted()) {
                    try {
                        val pc = cameraManager.getCameraCharacteristics(p)
                        list.add(CamEntry(id, p, "[$id>$p] $name ${focalDesc(pc)}"))
                    } catch (e: Exception) {
                        // lente física não acessível para apps
                    }
                }
            }
        }
        entries = list
        entryIndex = if (defaultIndex >= 0) defaultIndex else 0
    }

    // =====================================================================
    // Abrir / fechar câmera
    // =====================================================================

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!resumed || opening || cameraDevice != null) return
        if (!hasCameraPermission() || !textureView.isAvailable) return
        if (bgHandler == null) return
        val entry = entries.getOrNull(entryIndex)
        if (entry == null) {
            toast("Nenhuma câmera encontrada.")
            return
        }
        try {
            val c = cameraManager.getCameraCharacteristics(entry.charsId)
            chars = c
            logicalChars = cameraManager.getCameraCharacteristics(entry.logicalId)
            setupCameraInfo(c)
            initSeeks()
            refreshUi()
            opening = true
            cameraManager.openCamera(entry.logicalId, stateCallback, bgHandler)
        } catch (e: Exception) {
            opening = false
            toast("Não consegui abrir a câmera: ${e.message}")
        }
    }

    private fun closeCamera() {
        try {
            session?.close()
        } catch (e: Exception) {
            // ignora
        }
        session = null
        try {
            cameraDevice?.close()
        } catch (e: Exception) {
            // ignora
        }
        cameraDevice = null
        try {
            jpegReader?.close()
            rawReader?.close()
        } catch (e: Exception) {
            // ignora
        }
        jpegReader = null
        rawReader = null
        val j = job
        job = null
        try {
            j?.jpeg?.close()
            j?.raw?.close()
        } catch (e: Exception) {
            // ignora
        }
        previewSurface?.release()
        previewSurface = null
        opening = false
    }

    private fun restartCamera() {
        closeCamera()
        opening = true // segura reaberturas até o atraso abaixo
        runOnUiThread { btnShutter.isEnabled = true; btnShutter.alpha = 1f }
        mainHandler.postDelayed({
            opening = false
            openCamera()
        }, 300)
    }

    private val stateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            opening = false
            if (!resumed) {
                camera.close()
                return
            }
            cameraDevice = camera
            createSession()
        }

        override fun onDisconnected(camera: CameraDevice) {
            opening = false
            camera.close()
            cameraDevice = null
        }

        override fun onError(camera: CameraDevice, error: Int) {
            opening = false
            camera.close()
            cameraDevice = null
            toast("Erro da câmera (código $error). Tente outra câmera ou reinicie o app.")
        }
    }

    // =====================================================================
    // Capacidades da câmera selecionada
    // =====================================================================

    private fun setupCameraInfo(c: CameraCharacteristics) {
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()

        // tamanhos de JPEG (maior primeiro)
        val all = map?.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()
        var list = all.filter { it.width.toLong() * it.height >= 2_000_000L }
            .sortedByDescending { it.width.toLong() * it.height }
        if (list.isEmpty()) list = all.sortedByDescending { it.width.toLong() * it.height }
        jpegSizes = list
        if (jpegSizeIndex >= jpegSizes.size) jpegSizeIndex = 0

        // RAW
        val rs = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
        rawSize = if (rs != null && rs.isNotEmpty() &&
            caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW)
        ) {
            rs.maxByOrNull { it.width.toLong() * it.height }
        } else {
            null
        }
        rawSupported = rawSize != null
        if (!rawSupported) rawMode = false

        // exposição manual
        val isoR = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val expR = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        manualSupported = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) &&
            isoR != null && expR != null
        isoMin = isoR?.lower ?: 100
        isoMax = isoR?.upper ?: 100
        expMin = expR?.lower ?: 1_000_000L
        expMax = maxOf(expMin, minOf(expR?.upper ?: expMin, MAX_EXPOSURE_NS))
        if (!manualSupported) manualExposure = false

        // EV
        val evR = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        evMin = evR?.lower ?: 0
        evMax = evR?.upper ?: 0
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f

        // zoom
        val zr = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
        zoomMin = zr?.lower ?: 1f
        zoomMax = zr?.upper ?: 1f
        zoomRatio = zoomRatio.coerceIn(zoomMin, maxOf(zoomMin, zoomMax))

        // foco
        minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (minFocus <= 0f) manualFocus = false
        afContinuous = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            ?.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE) == true

        // balanço de branco
        val aw = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)
            ?.filter { it != CameraMetadata.CONTROL_AWB_MODE_OFF }
        awbModes = if (aw.isNullOrEmpty()) listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO) else aw
        if (awbIndex >= awbModes.size) awbIndex = 0

        // processamento
        nrMinimal = c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
            ?.contains(CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL) == true
        edgeOff = c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
            ?.contains(CameraMetadata.EDGE_MODE_OFF) == true
        if (!nrMinimal && !edgeOff) minimalProcessing = false
    }

    // =====================================================================
    // Sessão e preview
    // =====================================================================

    private fun choosePreviewSize(c: CameraCharacteristics, target: Size): Size {
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return Size(1280, 720)
        val sizes = map.getOutputSizes(SurfaceTexture::class.java) ?: return Size(1280, 720)
        val ratio = target.width.toDouble() / target.height
        val good = sizes.filter {
            it.width <= 1920 && it.height <= 1440 &&
                abs(it.width.toDouble() / it.height - ratio) < 0.02
        }
        val best = good.maxByOrNull { it.width * it.height }
        if (best != null) return best
        val fallback = sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
        return fallback ?: sizes[0]
    }

    private fun cfg(s: Surface, e: CamEntry): OutputConfiguration {
        val o = OutputConfiguration(s)
        val p = e.physicalId
        if (p != null) o.setPhysicalCameraId(p)
        return o
    }

    private fun createSession() {
        val device = cameraDevice ?: return
        val c = chars ?: return
        val entry = entries.getOrNull(entryIndex) ?: return
        val jSize = jpegSizes.getOrNull(jpegSizeIndex)
        if (jSize == null) {
            toast("Esta câmera não informa tamanhos de JPEG.")
            return
        }
        try {
            previewSize = choosePreviewSize(c, jSize)
            val st = textureView.surfaceTexture
            if (st == null) {
                toast("Preview ainda não está pronto.")
                return
            }
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            runOnUiThread { textureView.setAspectRatio(previewSize.height, previewSize.width) }

            previewSurface?.release()
            val surf = Surface(st)
            previewSurface = surf

            jpegReader?.close()
            val jr = ImageReader.newInstance(jSize.width, jSize.height, ImageFormat.JPEG, 2)
            jr.setOnImageAvailableListener(jpegListener, bgHandler)
            jpegReader = jr

            rawReader?.close()
            rawReader = null
            val outputs = ArrayList<OutputConfiguration>()
            outputs.add(cfg(surf, entry))
            outputs.add(cfg(jr.surface, entry))

            val rSize = rawSize
            if (rawMode && rawSupported && rSize != null) {
                val rr = ImageReader.newInstance(rSize.width, rSize.height, ImageFormat.RAW_SENSOR, 2)
                rr.setOnImageAvailableListener(rawListener, bgHandler)
                rawReader = rr
                outputs.add(cfg(rr.surface, entry))
            }

            val sc = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                outputs,
                sessionExecutor,
                sessionCallback
            )
            device.createCaptureSession(sc)
        } catch (e: Exception) {
            toast("Erro ao criar sessão: ${e.message}")
        }
    }

    private val sessionCallback = object : CameraCaptureSession.StateCallback() {
        override fun onConfigured(s: CameraCaptureSession) {
            session = s
            startPreview()
        }

        override fun onConfigureFailed(s: CameraCaptureSession) {
            toast("Falha ao configurar a câmera com essa combinação (resolução/RAW/lente). Tente outra opção.")
        }
    }

    private val previewCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            s: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExp = it }
            result.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { lastFocus = it }
        }
    }

    private fun applySettings(b: CaptureRequest.Builder) {
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        if (zoomMax > zoomMin) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoomRatio)
        b.set(CaptureRequest.CONTROL_AWB_MODE, awbModes[awbIndex.coerceIn(0, awbModes.size - 1)])

        if (manualFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter)
        } else if (afContinuous) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }

        if (manualExposure && manualSupported) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoValue)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNs)
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex)
        }

        if (minimalProcessing) {
            if (nrMinimal) {
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL)
            }
            if (edgeOff) {
                b.set(CaptureRequest.EDGE_MODE, CameraMetadata.EDGE_MODE_OFF)
            }
        }
    }

    private fun startPreview() {
        val device = cameraDevice ?: return
        val s = session ?: return
        val surf = previewSurface ?: return
        try {
            val b = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(surf)
            applySettings(b)
            s.setRepeatingRequest(b.build(), previewCallback, bgHandler)
        } catch (e: Exception) {
            toast("Preview: ${e.message}")
        }
    }

    // =====================================================================
    // Captura
    // =====================================================================

    private fun computeJpegOrientation(): Int {
        val lc = logicalChars ?: return 0
        val sensor = lc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0
        var d = if (deviceOrientation == OrientationEventListener.ORIENTATION_UNKNOWN) {
            0
        } else {
            (deviceOrientation + 45) / 90 * 90
        }
        if (lc.get(CameraCharacteristics.LENS_FACING) == CameraMetadata.LENS_FACING_FRONT) d = -d
        return (sensor + d + 360) % 360
    }

    private fun exifFromDegrees(deg: Int): Int = when (deg) {
        90 -> EXIF_ROTATE_90
        180 -> EXIF_ROTATE_180
        270 -> EXIF_ROTATE_270
        else -> EXIF_NORMAL
    }

    private fun takePicture() {
        val device = cameraDevice
        val s = session
        val jr = jpegReader
        val c = chars
        if (device == null || s == null || jr == null || c == null) {
            toast("A câmera ainda não está pronta.")
            return
        }
        if (job != null) return
        val entry = entries.getOrNull(entryIndex) ?: return
        try {
            val b = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(jr.surface)
            val rr = rawReader
            if (rr != null) b.addTarget(rr.surface)
            applySettings(b)
            val orientation = computeJpegOrientation()
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            b.set(CaptureRequest.JPEG_ORIENTATION, orientation)

            val thisJob = CaptureJob(rr != null, orientation, c, entry.physicalId)
            job = thisJob
            btnShutter.isEnabled = false
            btnShutter.alpha = 0.4f
            s.capture(b.build(), captureCallback, bgHandler)

            // evita travar o botão se algo nunca chegar
            mainHandler.postDelayed({
                if (job === thisJob) {
                    job = null
                    try {
                        thisJob.jpeg?.close()
                        thisJob.raw?.close()
                    } catch (e: Exception) {
                        // ignora
                    }
                    btnShutter.isEnabled = true
                    btnShutter.alpha = 1f
                    toast("Tempo esgotado na captura.")
                }
            }, 25000)
        } catch (e: Exception) {
            job = null
            btnShutter.isEnabled = true
            btnShutter.alpha = 1f
            toast("Erro ao fotografar: ${e.message}")
        }
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            s: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            val j = job ?: return
            j.result = result
            tryFinish()
        }

        override fun onCaptureFailed(
            s: CameraCaptureSession,
            request: CaptureRequest,
            failure: CaptureFailure
        ) {
            val j = job
            job = null
            try {
                j?.jpeg?.close()
                j?.raw?.close()
            } catch (e: Exception) {
                // ignora
            }
            runOnUiThread {
                btnShutter.isEnabled = true
                btnShutter.alpha = 1f
            }
            toast("A captura falhou.")
        }
    }

    private val jpegListener = ImageReader.OnImageAvailableListener { reader ->
        val img = try {
            reader.acquireNextImage()
        } catch (e: Exception) {
            null
        }
        if (img != null) {
            val j = job
            if (j == null || j.jpeg != null) {
                img.close()
            } else {
                j.jpeg = img
                tryFinish()
            }
        }
    }

    private val rawListener = ImageReader.OnImageAvailableListener { reader ->
        val img = try {
            reader.acquireNextImage()
        } catch (e: Exception) {
            null
        }
        if (img != null) {
            val j = job
            if (j == null || j.raw != null) {
                img.close()
            } else {
                j.raw = img
                tryFinish()
            }
        }
    }

    /** Roda sempre na thread de fundo (todos os callbacks usam o mesmo handler). */
    private fun tryFinish() {
        val j = job ?: return
        val res = j.result ?: return
        val jp = j.jpeg ?: return
        if (j.expectRaw && j.raw == null) return
        job = null

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val msg = StringBuilder()

        try {
            val buf = jp.planes[0].buffer
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            val where = writeFile("CAM_$stamp.jpg", "image/jpeg") { it.write(bytes) }
            msg.append("JPEG ${jp.width}x${jp.height} salvo em $where")
        } catch (e: Exception) {
            msg.append("Erro ao salvar JPEG: ${e.message}")
        } finally {
            try {
                jp.close()
            } catch (e: Exception) {
                // ignora
            }
        }

        val rw = j.raw
        if (rw != null) {
            try {
                val pid = j.physicalId
                val r: CaptureResult = (if (pid != null) res.physicalCameraResults[pid] else null) ?: res
                val where = writeFile("CAM_$stamp.dng", "image/x-adobe-dng") { os ->
                    val dng = DngCreator(j.chars, r)
                    try {
                        dng.setOrientation(exifFromDegrees(j.jpegOrientation))
                        dng.writeImage(os, rw)
                    } finally {
                        dng.close()
                    }
                }
                msg.append("\nDNG ${rw.width}x${rw.height} salvo em $where")
            } catch (e: Exception) {
                msg.append("\nErro ao salvar DNG: ${e.message}")
            } finally {
                try {
                    rw.close()
                } catch (e: Exception) {
                    // ignora
                }
            }
        }

        runOnUiThread {
            btnShutter.isEnabled = true
            btnShutter.alpha = 1f
            toast(msg.toString())
        }
    }

    private fun writeFile(name: String, mime: String, writer: (OutputStream) -> Unit): String {
        var uri: Uri?
        try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CamPro")
            uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        } catch (e: Exception) {
            uri = null
        }
        if (uri != null) {
            val os = contentResolver.openOutputStream(uri) ?: throw IOException("Não consegui abrir o arquivo")
            os.use { writer(it) }
            return "Pictures/CamPro/$name"
        }
        // plano B: pasta do próprio app
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
        val f = File(dir, name)
        FileOutputStream(f).use { writer(it) }
        return f.absolutePath
    }

    // =====================================================================
    // Relatório "Info"
    // =====================================================================

    private fun showInfo() {
        val report = try {
            buildReport()
        } catch (e: Exception) {
            "Erro ao montar relatório: ${e.message}"
        }
        val tv = TextView(this)
        tv.text = report
        tv.textSize = 11f
        tv.typeface = Typeface.MONOSPACE
        tv.setTextIsSelectable(true)
        tv.setPadding(24, 16, 24, 16)
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("O que o aparelho libera")
            .setView(sv)
            .setPositiveButton("Copiar") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("cameras", report))
                toast("Copiado!")
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun sizeDesc(a: Array<Size>?): String {
        if (a == null || a.isEmpty()) return "nenhum"
        val m = a.maxByOrNull { it.width.toLong() * it.height } ?: return "nenhum"
        return String.format(Locale.US, "%dx%d (%.1f MP)", m.width, m.height, m.width.toLong() * m.height / 1e6)
    }

    private fun capName(cap: Int): String = when (cap) {
        0 -> "BACKWARD_COMPATIBLE"
        1 -> "MANUAL_SENSOR"
        2 -> "MANUAL_POST_PROCESSING"
        3 -> "RAW"
        6 -> "BURST_CAPTURE"
        11 -> "LOGICAL_MULTI_CAMERA"
        16 -> "ULTRA_HIGH_RESOLUTION_SENSOR"
        else -> "cap$cap"
    }

    private fun hwName(level: Int?): String = when (level) {
        0 -> "LIMITED"
        1 -> "FULL"
        2 -> "LEGACY"
        3 -> "LEVEL_3"
        4 -> "EXTERNAL"
        else -> "?"
    }

    private fun describe(sb: StringBuilder, camId: String, title: String) {
        val c = cameraManager.getCameraCharacteristics(camId)
        sb.append("== ").append(title).append(" ==\n")
        sb.append("Lente: ").append(facingName(c.get(CameraCharacteristics.LENS_FACING)))
            .append(' ').append(focalDesc(c)).append('\n')
        sb.append("Nível de hardware: ")
            .append(hwName(c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL))).append('\n')
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        sb.append("Capacidades: ").append(caps.joinToString(", ") { capName(it) }).append('\n')
        c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)?.let {
            sb.append("Sensor (pixels): ${it.width}x${it.height}\n")
        }
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        sb.append("JPEG máx. (padrão): ").append(sizeDesc(map?.getOutputSizes(ImageFormat.JPEG))).append('\n')
        sb.append("RAW máx. (padrão): ").append(sizeDesc(map?.getOutputSizes(ImageFormat.RAW_SENSOR))).append('\n')
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mr = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
            if (mr != null) {
                sb.append("JPEG máx. (alta resolução): ").append(sizeDesc(mr.getOutputSizes(ImageFormat.JPEG))).append('\n')
                sb.append("RAW máx. (alta resolução): ").append(sizeDesc(mr.getOutputSizes(ImageFormat.RAW_SENSOR))).append('\n')
            } else {
                sb.append("Modo alta resolução (sensor): não informado\n")
            }
        }
        c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let {
            sb.append("ISO: ${it.lower} a ${it.upper}\n")
        }
        c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let {
            sb.append("Obturador: ${it.lower / 1000} µs a ${it.upper / 1_000_000} ms\n")
        }
        c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let {
            sb.append("Zoom: ${it.lower}x a ${it.upper}x\n")
        }
        c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)?.let {
            sb.append("Foco manual (dioptrias máx.): $it\n")
        }
        sb.append('\n')
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        sb.append("Aparelho: ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")
        sb.append("Câmeras que o sistema mostra para apps de terceiros:\n\n")
        val ids = cameraManager.cameraIdList.toList()
        for (id in ids) {
            try {
                describe(sb, id, "Câmera $id")
            } catch (e: Exception) {
                sb.append("Câmera $id: erro ${e.message}\n\n")
            }
            try {
                val c = cameraManager.getCameraCharacteristics(id)
                for (p in c.physicalCameraIds.sorted()) {
                    try {
                        describe(sb, p, "  lente física $p (dentro da câmera $id)")
                    } catch (e: Exception) {
                        sb.append("  lente física $p: não acessível (${e.message})\n\n")
                    }
                }
            } catch (e: Exception) {
                // ignora
            }
        }
        return sb.toString()
    }

    // =====================================================================
    // Utilidades de escala logarítmica (ISO, obturador, zoom)
    // =====================================================================

    private fun logMap(p: Int, lo: Double, hi: Double): Double {
        if (hi <= lo) return lo
        return lo * (hi / lo).pow(p / 1000.0)
    }

    private fun logUnmap(v: Double, lo: Double, hi: Double): Int {
        if (hi <= lo || v <= 0.0) return 0
        return (1000.0 * ln(v / lo) / ln(hi / lo)).roundToInt().coerceIn(0, 1000)
    }
}
