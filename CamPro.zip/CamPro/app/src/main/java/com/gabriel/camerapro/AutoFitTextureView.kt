package com.gabriel.camerapro

import android.content.Context
import android.util.AttributeSet
import android.view.TextureView

/** TextureView que se ajusta a uma proporção (largura:altura) sem esticar a imagem. */
class AutoFitTextureView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : TextureView(context, attrs, defStyle) {

    private var ratioW = 0
    private var ratioH = 0

    fun setAspectRatio(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        ratioW = w
        ratioH = h
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = MeasureSpec.getSize(heightMeasureSpec)
        if (ratioW == 0 || ratioH == 0) {
            setMeasuredDimension(width, height)
        } else if (width < height * ratioW / ratioH) {
            setMeasuredDimension(width, width * ratioH / ratioW)
        } else {
            setMeasuredDimension(height * ratioW / ratioH, height)
        }
    }
}
